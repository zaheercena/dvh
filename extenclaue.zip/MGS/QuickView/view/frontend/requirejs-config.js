var config = {
    map: {
        '*': {
            mgs_quickview: 'MGS_QuickView/js/mgs_quickview'
        }
    }
};
