<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MGS\Mpanel\Block\Panel\Edit;

use MGS\Mpanel\Block\Panel\AbstractPanel;

/**
 * Main contact form block
 */
class Content extends AbstractPanel
{
	
}

