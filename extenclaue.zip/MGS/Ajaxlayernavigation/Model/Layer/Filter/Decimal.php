<?php
namespace MGS\Ajaxlayernavigation\Model\Layer\Filter;

class Decimal extends \Magento\Catalog\Model\Layer\Filter\Decimal
{

}
