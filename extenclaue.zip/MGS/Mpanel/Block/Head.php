<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MGS\Mpanel\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Head extends Template
{
	
}

